let elm01 = document.getElementById("01");
let elm02 = document.getElementById("02");
let elm03 = document.getElementById("02");
let elm04 = document.getElementById("02");
let currentDate = new Date();
elm01.innerText = currentDate
let Year = currentDate.getFullYear();
let Month = currentDate.getMonth()
let onlyDate = currentDate.getDate()
let Day = currentDate.getDay()
var crrTime
// let currentTime = currentDate.now()

let FullClock = setInterval(function(){
    let Hour = currentDate.getHours()
    let Minutes = currentDate.getMinutes()
    let Seconds = currentDate.getSeconds()
    return crrTime = Hour + ' ' + Minutes + ' ' + Seconds

},1000)
// let Day = currentDate.getDay()
elm01.innerText = "Date Formate is DD/MM/YYYY " + onlyDate + '/' + Month + '/' + Year
elm02.innerText = "Date Formate is DD-MM-YYYY " + onlyDate + '-' + Month + '-' + Year
let DayArray = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
let MonthArry = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'Sepember', 'October', 'November', 'December']
elm03.innerText = "Today is : " + DayArray[Day]
elm04.innerText = "Current Time is : " + crrTime
