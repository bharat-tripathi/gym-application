import React, { useState } from 'react';

export default function AddRecord() {

    const [userData, setUserData] = useState({
        username: '',
        age: '' 
    })

    const addUserData = (data) => {
        debugger
        console.log(data)
        let existingdata = localStorage.getItem('user');
        let updateddata = [JSON.parse(existingdata)]
        if (!existingdata) {
            localStorage.setItem('user', JSON.stringify(data))
        } else {
            updateddata.push(data)
            localStorage.setItem('user', JSON.stringify(updateddata))
            console.log(updateddata);
        }
    }

    const handleChange = (e) => {
        let controlledName = e.target.name
        let controlledValue = e.target.value
        setUserData({
            ...userData,
            [controlledName]: controlledValue
        })
    }

    const handleSubmit = (e) => {
        e.preventDefault()
        addUserData(userData)
    }

    return (
        <>
            <div className="col-sm-12 mb-4">
                <div className="row justify-content-center">
                    <div className="col-sm-6 text-center shadow p-4">
                        <form onSubmit={handleSubmit}>
                            <div className="form-group row ">
                                <label>Name</label>
                                <input
                                    type="text"
                                    onChange={handleChange}
                                    className="form-control"
                                    name="username"
                                    placeholder="Enter User's Name" />
                            </div>
                            <div className="form-group row ">
                                <label>Age</label>
                                <input
                                    type="number"
                                    onChange={handleChange}
                                    className="form-control"
                                    name="age"
                                    placeholder="Enter User's Age" />
                            </div>
                            <button className="btn btn-success" type="submit" >Add</button>
                        </form>
                    </div>
                </div>
            </div>
        </>
    )
}