import ExpenseItem from "./components/ExpenseItem";
import Expense from "./components/Expense";

function App() {
  return (
    <div>
      <h2>Let's get started!</h2>
      <Expense />
    </div>
  );
}

export default App;
