import React from 'react';

function Header() {
    return (
        <>
            <nav class="navbar navbar-light bg-light">
                <span class="navbar-brand mb-0 h1">Search Box</span>
            </nav>
        </>
    )
}

export default Header