import React from 'react';

export default function ViewDetails(props) {
    // Data Coming as props from parent SearchBox Component
    const searchResult = props.searchResult;

    return (
        <>
            {/* View Records */}
            <div className="col-sm-12">
                <div className='row justify-content-center mt-3'>
                    <div className="col-sm-6 border p-4 mb-4">
                        {searchResult.length > 0 ?
                            <ul>
                                {searchResult.map(item => <li className="shadow p-3">{`Name is ${item.name} and Age is ${item.age}`}</li>)}
                            </ul> : <ul>
                                <li className="shadow bg-danger text-white p-3 text-center">Not Found</li>
                            </ul>}
                    </div>
                </div>
            </div>
        </>
    )
}