import React, { useState } from 'react';
import ViewDetails from './ViewDetails';

function SearchBox(props) {
    // Data Coming as props from parent App Component
    const data = props.data;

    // State Hook for Filtered search values - Array Type
    const [searchResult, setSearchResult] = useState(data);

    // State Hook for Input value - String Type
    const [textValue, setTextValue] = useState('');

    // Empty array for filtered Data
    let filterData = [];
    // Below Function is to perform search or filter Logics
    // In case of search on button click remove handlesearch method call from handleChange method
    // remove/replace parameter valuev in the method from 'inputdata' from method to 'searchValue'

    const handleSearch = (inputdata) => {
        if (inputdata.length > 0) {
            for (let item of data) {
                // OR || condition is searching for both age and name 
                // remove one condition in case of search with only single condition
                if (parseInt(inputdata) == item.age || (item.name).includes(inputdata)) {
                    filterData.push(item)
                    setSearchResult(filterData)
                }
            }
            setSearchResult(filterData)
        } else {
            setSearchResult(data)
        }
    }
    // Getting the textbox value to input text
    const handleChange = (e) => {
        debugger
        const inputdata = e.target.value
        setTextValue(inputdata)
        handleSearch(inputdata)
    }
    return (
        <>
            {/* Input Search Text */}
            <div className="col-sm-12">
                <div className="row justify-content-center">
                    <div className="col-sm-6 text-center shadow p-4">
                        <div className="form-group">
                            <label>Type Name or Age to search</label>
                            <input type="text" onChange={handleChange} className="form-control" name="text" value={textValue} placeholder="Enter text to search" />
                        </div>
                        {/* Uncomment the button in case of search the result on button click */}
                        {/* <button className="btn btn-primary" onClick={handleSearch}>Search</button> */}
                    </div>
                </div>
            </div>
            <ViewDetails searchResult = {searchResult}/>
        </>
    )
}

export default SearchBox