let data = [{
    "name": "bharat",
    "age": 32 
},
{
    "name": "akshat",
    "age": 1
},
{
    "name": "akash",
    "age": 22
},
{
    "name": "ravi",
    "age": 32
},
{
    "name": "shatrughan",
    "age": 21
},
{
    "name": "kamal",
    "age": 32
},
{
    "name": "satyam",
    "age": 22
}]

export default data