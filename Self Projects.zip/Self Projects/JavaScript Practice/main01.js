const getData = ()=> {
    console.log("Getting Data...");
}

const debounce = (func, delay)=>{
    let timeoutID;
    return ()=>{
        if(timeoutID) {
            clearTimeout(timeoutID);
        }
        timeoutID = setTimeout(()=>{
            func()
        },delay);
    };
};

let elminput = document.getElementById("inputBox").addEventListener("keyup", debounce(getData, 500));

let elmbtn = document.getElementById("btn").addEventListener("click", debounce(getData, 500));

