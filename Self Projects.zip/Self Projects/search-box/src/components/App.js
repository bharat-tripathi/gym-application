import React from 'react';
import Header from './Header';
import SearchBox from './SearchBox';
import AddRecord from './AddRecord';
import data from './Data';

export default function Add() {
  
  return (
    <>
      <Header/>
      <AddRecord/>
      <SearchBox data={data}/>
    </>
  )
}